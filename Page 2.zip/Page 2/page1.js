function couleur_bouton1()
{
	document.getElementById("bouton1").className = "fond2";
}

function retour_couleur1()
{
	document.getElementById("bouton1").className = "fond1";
}

function couleur_bouton2()
{
	document.getElementById("bouton2").className = "fond2";
}

function retour_couleur2()
{
	document.getElementById("bouton2").className = "fond1";
}